-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.28-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para blog_db
CREATE DATABASE IF NOT EXISTS `blog_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `blog_db`;

-- Volcando estructura para tabla blog_db.entries
CREATE TABLE IF NOT EXISTS `entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publish_date` date NOT NULL DEFAULT curdate(),
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla blog_db.entries: ~5 rows (aproximadamente)
INSERT INTO `entries` (`id`, `title`, `author`, `publish_date`, `content`) VALUES
	(1, 'Entrada 1', 'Isvi Lerma', '2022-03-01', 'Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno  Uno '),
	(2, 'Entrada 2', 'Mizraim Rosas', '2022-03-02', 'Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos Dos '),
	(3, 'Entrada 3', 'Lorem', '2022-03-03', 'Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres Tres '),
	(4, 'Entrada 4', 'Steve Jobs', '2022-03-03', 'Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro Cuatro '),
	(7, 'Entrada 5', 'Bill', '2024-02-28', 'Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco Cinco '),
	(9, 'Entrada 6', 'Mark', '2024-02-28', 'Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis Seis ');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
